import cv2
import numpy as np

def third_derivative_approximation(image):
   
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
   
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    dx3 = cv2.Laplacian(laplacian, cv2.CV_64F)
    
    
    threshold = 100
    edges = np.abs(dx3)
    edges[edges < threshold] = 0
    edges[edges >= threshold] = 255
    
    return edges.astype(np.uint8)

image = cv2.imread('buttefly.png')


edges_third_derivative = third_derivative_approximation(image)

cv2.imshow('Original', image)
cv2.imshow('Edges (Third Derivative Approximation)', edges_third_derivative)
cv2.waitKey(0)
cv2.destroyAllWindows()

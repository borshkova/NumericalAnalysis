import cv2
import numpy as np


img = cv2.imread('buttefly.png', cv2.IMREAD_GRAYSCALE)


LoG = cv2.GaussianBlur(img, (5, 5), 0)#შეამციროს ხმაური
LoG = cv2.Laplacian(LoG, cv2.CV_64F)# detect edges and features.

#  Determinant of Hessian filter და ითვლის მეორე წარმოეულებს 
DoH = cv2.GaussianBlur(img, (5, 5), 0)
Dxx = cv2.Sobel(DoH, cv2.CV_64F, 2, 0)
Dyy = cv2.Sobel(DoH, cv2.CV_64F, 0, 2)
Dxy = cv2.Sobel(DoH, cv2.CV_64F, 1, 1)
DoH = (Dxx * Dyy) - (Dxy ** 2)

# blob პატარა ბიტიან ფოტოებს ღებულობს ამიტომ გადაგვყავს 8 ბიტიანში/
LoG_8bit = cv2.convertScaleAbs(LoG)
DoH_8bit = cv2.convertScaleAbs(DoH)

# ბლობ დეთექშენია 
params = cv2.SimpleBlobDetector_Params()
params.filterByArea = True
params.minArea = 10
params.filterByCircularity = False
params.filterByConvexity = False
params.filterByInertia = False

detector = cv2.SimpleBlobDetector_create(params)
keypoints_LoG = detector.detect(LoG_8bit)
keypoints_DoH = detector.detect(DoH_8bit)

img_with_keypoints_LoG = cv2.drawKeypoints(img, keypoints_LoG, np.array([]), (0, 0, 255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
img_with_keypoints_DoH = cv2.drawKeypoints(img, keypoints_DoH, np.array([]), (0, 255, 255), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)


cv2.imshow('LoG Keypoints', img_with_keypoints_LoG)
cv2.imshow('DoH Keypoints', img_with_keypoints_DoH)
cv2.waitKey(0)
cv2.destroyAllWindows()



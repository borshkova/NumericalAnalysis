import cv2
import numpy as np


image = cv2.imread("dog.jpg")

gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

edges = cv2.Canny(gray_image, 50, 150)


cv2.imshow('Original Image', image)
cv2.waitKey(0)
cv2.destroyAllWindows()

cv2.imshow('Edges Detected', edges)
cv2.waitKey(0)
cv2.destroyAllWindows()


kernel = np.array([[0, -1, 0],
                   [-1, 5, -1],
                   [0, -1, 0]])

image_sharp = cv2.filter2D(src=image, ddepth=-1, kernel=kernel)

cv2.imshow('Sharpened Image', image_sharp)
cv2.waitKey(0)
cv2.destroyAllWindows()

import cv2 
import numpy as np 
import matplotlib.pyplot as plt
 #კითხულობს ფოტოს
img = cv2.imread('buttefly.png') 
# გვიჩვენებს ორიგინალ ფოტოს და ამაში გვეხმარება მეოთხე ხაზიც 
cv2.imshow('Original', img)
cv2.waitKey(0)
 
#გადაგვყავს ნაცრისფერ ტონალობაში(გადაეცემა ფოტო და კონვერტაციის კოდი ანუ BRG-დან გვინდა გადავიდეთ ნაცრისფერში.)
img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
#ვიყენებთ გაუსიან დაბურვას. გვეხმარება ხმაურის და დეტალების შემცირებაში(გადაეცემა ფოტო, კერნელის ზომა=ბუნდოვანი ფილტრის ზომა, გადახრა x,y მიმართულებით)
img_blur = cv2.GaussianBlur(img_gray, (3,3), 0) 
 
#სობელის დეთექშენი
sobelx1 = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=0, ksize=3)
sobelx = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=0, ksize=5) #x-ის მიმართ (dx=1 dy=0) კერნელი=5 უფრო სტაბილური შედეგისთვის უმჯობესია 3X3 შედარებით
sobely1 = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=0, dy=1, ksize=3)
sobely = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=0, dy=1, ksize=5)
sobelxy1 = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=3) 
sobelxy = cv2.Sobel(src=img_blur, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=5) 

cv2.imshow('Sobel X, Kernel size = 3 ', sobelx1)
cv2.waitKey(0)

cv2.imshow('Sobel X, Kernel size = 5', sobelx)
cv2.waitKey(0)

cv2.imshow('Sobel Y, Kernel size = 3', sobely1)
cv2.waitKey(0)

cv2.imshow('Sobel Y, Kernel size = 5', sobely)
cv2.waitKey(0)

cv2.imshow('Sobel X Y using Sobel() function, kernel = 3 ', sobelxy1)
cv2.waitKey(0)

cv2.imshow('Sobel X Y using Sobel() function, kernel = 5', sobelxy)
cv2.waitKey(0)
 
# canny edge detection
edges = cv2.Canny(image=img_blur, threshold1=100, threshold2=200) #

cv2.imshow('Canny Edge Detection', edges)
cv2.waitKey(0)
 
cv2.destroyAllWindows()


# Scharr algorithm
img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
plt.imshow(img, cmap='gray')
fieldx = cv2.Scharr(img, cv2.CV_32F, 1, 0) / 15.36
cv2.imshow('X Gradient', fieldx)
cv2.waitKey(0)

fieldy = cv2.Scharr(img, cv2.CV_32F, 0, 1) / 15.36
cv2.imshow('Y Gradient', fieldy)
cv2.waitKey(0)

# Close all OpenCV windows
cv2.destroyAllWindows()

#laplacian
img = cv2.imread('buttefly.png')
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
img = cv2.GaussianBlur(img,(13,13),0)
edges = cv2.Laplacian(img, -1, ksize=5, scale=1,delta=0,borderType=cv2.BORDER_DEFAULT) #-1 ნიშნავს deth იქნება ერთნაირი შემაალი და გამომავალი ფოტოებისთვის
#კონტურის ტიპი  რომელსაც ვიყენებთ კონტერურების ექსტრაპოლაციისთვის 
output = [img, edges]
titles = ['Original', 'after laplacian ,kernel size= 5']

for i in range(2):
    plt.subplot(1, 2, i + 1)
    plt.imshow(output[i], cmap='gray')
    plt.title(titles[i])
    plt.xticks([])
    plt.yticks([])
plt.show()


#ერორები  სობელის მეთოდისთვის

error_sobelx = np.abs(sobelx1 - sobelx)
error_norm = np.linalg.norm(error_sobelx)
print("L2 Norm of Error:", error_norm)


error_inf_norm = np.max(np.abs(sobelx1 - sobelx))
print("Infinity Norm of Error:", error_inf_norm)

error_l1_norm = np.sum(np.abs(sobelx1 - sobelx))
print("L1 Norm of Error:", error_l1_norm)
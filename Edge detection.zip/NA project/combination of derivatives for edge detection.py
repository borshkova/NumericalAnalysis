import cv2
import numpy as np
import matplotlib.pyplot as plt


image = cv2.imread('buttefly.png', cv2.IMREAD_GRAYSCALE)

# LOG -filter ( laplacian of gaussian)
log_filter = np.array([[0, 0, -1, 0, 0],
                       [0, -1, -2, -1, 0],
                       [-1, -2, 16, -2, -1],
                       [0, -1, -2, -1, 0],
                       [0, 0, -1, 0, 0]])

directional_filter = np.array([[-1, -2, -1],
                                [0, 0, 0],
                                [1, 2, 1]])


coeff_log = 0.7
coeff_directional = 0.4


edge_log = cv2.filter2D(image, -1, log_filter)
edge_directional = cv2.filter2D(image, -1, directional_filter)


edges = coeff_log * edge_log + coeff_directional * edge_directional


threshold = 50
edges[edges < threshold] = 0
edges[edges >= threshold] = 255


plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(image, cmap='gray')
plt.title('Original Image')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(edges, cmap='gray')
plt.title('Edge Map')
plt.axis('off')

plt.show()

import cv2
import numpy as np


img = cv2.imread('buttefly.png', cv2.IMREAD_GRAYSCALE)


blurred_img = cv2.GaussianBlur(img, (15, 15), 0)

uniform_img = np.ones_like(img) * 127  

# კობინაცია  ხმაურ მოშორებული ფოტოსი და ორიგინალი ფოტოსი რომელიც გადაყვანილია ნაცრისფერში
combined_img = cv2.addWeighted(blurred_img, 0.5, uniform_img, 0.5, 0)


params = cv2.SimpleBlobDetector_Params()
params.filterByArea = True
params.minArea = 10
params.filterByCircularity = False
params.filterByConvexity = False
params.filterByInertia = False

detector = cv2.SimpleBlobDetector_create(params)
keypoints = detector.detect(combined_img)


img_with_keypoints = cv2.drawKeypoints(img, keypoints, np.array([]), (0, 255, 0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)


cv2.imshow('Original Image', img)
cv2.imshow('Combined Image with Keypoints', img_with_keypoints)

cv2.waitKey(0)
cv2.destroyAllWindows()

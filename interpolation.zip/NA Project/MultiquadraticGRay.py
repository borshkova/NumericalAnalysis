import cv2
import numpy as np
from scipy.spatial.distance import cdist


image = cv2.imread('image.jpg', cv2.IMREAD_GRAYSCALE)
height, width = image.shape


image_normalized = image / 255.0

num_points = 600
control_points = np.column_stack((np.random.randint(0, height, num_points),
                                  np.random.randint(0, width, num_points)))
control_values = image_normalized[control_points[:, 0], control_points[:, 1]]


def mq_rbf_interpolation(points, values, xi, c):
    r = cdist(points, points, 'euclidean')
    phi = np.sqrt(r**2 + c**2)
    weights = np.linalg.solve(phi, values)
    
    r_xi = cdist(xi, points, 'euclidean')
    phi_xi = np.sqrt(r_xi**2 + c**2)
    
    return np.dot(phi_xi, weights)


grid_x, grid_y = np.mgrid[0:height, 0:width]
grid_points = np.column_stack((grid_x.ravel(), grid_y.ravel()))


shape_parameter = 0.5  
interpolated_values = mq_rbf_interpolation(control_points, control_values, grid_points, shape_parameter)


interpolated_image = interpolated_values.reshape((height, width))


interpolated_image = (interpolated_image * 255).astype(np.uint8)

cv2.imwrite('interpolated_image.jpg', interpolated_image)
cv2.imshow('Interpolated Image', interpolated_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

import cv2
import numpy as np
from scipy.interpolate import Rbf
import matplotlib.pyplot as plt

def load_image(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    return image / 255.0  # Normalize to [0, 1]

def downsample_image(image, scale_factor):
    width = int(image.shape[1] * scale_factor)
    height = int(image.shape[0] * scale_factor)
    return cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)

def upsample_image(image, original_shape):
    return cv2.resize(image, (original_shape[1], original_shape[0]), interpolation=cv2.INTER_LINEAR)

def multiquadric_rbf_interpolation(image, epsilon):
    x, y = np.mgrid[0:image.shape[0], 0:image.shape[1]]
    x = x.ravel()
    y = y.ravel()
    z = image.ravel()
    
    rbf = Rbf(x, y, z, function='multiquadric', epsilon=epsilon)
    
    xi, yi = np.mgrid[0:image.shape[0], 0:image.shape[1]]
    interpolated_image = rbf(xi, yi)
    
    return interpolated_image

def inverse_multiquadric_rbf_interpolation(image, epsilon):
    x, y = np.mgrid[0:image.shape[0], 0:image.shape[1]]
    x = x.ravel()
    y = y.ravel()
    z = image.ravel()
    
    rbf = Rbf(x, y, z, function='inverse_multiquadric', epsilon=epsilon)
    
    xi, yi = np.mgrid[0:image.shape[0], 0:image.shape[1]]
    interpolated_image = rbf(xi, yi)
    
    return interpolated_image

image_path = 'image.jpg'
image = load_image(image_path)

scale_factor = 0.2  
downsampled_image = downsample_image(image, scale_factor)

epsilon = 2
restored_mq_downsampled_image = multiquadric_rbf_interpolation(downsampled_image, epsilon)
restored_imq_downsampled_image = inverse_multiquadric_rbf_interpolation(downsampled_image, epsilon)

restored_mq_image = upsample_image(restored_mq_downsampled_image, image.shape)
restored_imq_image = upsample_image(restored_imq_downsampled_image, image.shape)

plt.figure(figsize=(15, 5))

plt.subplot(1, 3, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

plt.subplot(1, 3, 2)
plt.title('Restored Image (Multiquadric RBF)')
plt.imshow(restored_mq_image, cmap='gray')
plt.axis('off')

plt.subplot(1, 3, 3)
plt.title('Restored Image (Inverse Multiquadric RBF)')
plt.imshow(restored_imq_image, cmap='gray')
plt.axis('off')

plt.show()

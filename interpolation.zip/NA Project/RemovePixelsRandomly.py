import cv2
import numpy as np
import random

def remove_random_pixels(image, percentage):
    img_copy = np.copy(image)
    total_pixels = img_copy.shape[0] * img_copy.shape[1]
    num_pixels_to_remove = int(total_pixels * percentage / 100)

    pixels_to_remove = random.sample(range(total_pixels), num_pixels_to_remove)
    for index in pixels_to_remove:
        y = index // img_copy.shape[1]
        x = index % img_copy.shape[1]
        img_copy[y, x] = [0, 0, 0]  

    return img_copy

image = cv2.imread('image.jpg')


min_percentage = 10
max_percentage = 100

percentage = random.randint(min_percentage, max_percentage)

modified_image = remove_random_pixels(image, percentage)
cv2.imshow(f'{percentage}% Pixels Removed', modified_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

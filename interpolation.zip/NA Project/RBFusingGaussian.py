from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import Rbf


image_path = "image.jpg"
original_image = Image.open(image_path).convert('L')  
original_image = original_image.resize((original_image.width // 2, original_image.height // 2))
original_image_array = np.array(original_image)


missing_pixels = np.random.rand(*original_image_array.shape) < 0.1
corrupted_image_array = original_image_array.copy()
corrupted_image_array[missing_pixels] = 0

missing_indices = np.argwhere(missing_pixels)
grid_x, grid_y = np.meshgrid(np.arange(original_image_array.shape[1]), np.arange(original_image_array.shape[0]))

known_indices = np.argwhere(~missing_pixels)
known_values = original_image_array[~missing_pixels]

rbf = Rbf(*known_indices.T, known_values, function='gaussian')
interpolated_values = rbf(*missing_indices.T)

interpolated_image_array = corrupted_image_array.copy()
interpolated_image_array[missing_pixels] = interpolated_values

plt.figure(figsize=(10, 6))
plt.subplot(131)
plt.imshow(original_image_array, cmap='gray')
plt.title('Original Image')
plt.axis('off')

plt.subplot(132)
plt.imshow(corrupted_image_array, cmap='gray')
plt.title('Corrupted Image')
plt.axis('off')

plt.subplot(133)
plt.imshow(interpolated_image_array, cmap='gray')
plt.title('Interpolated Image')
plt.axis('off')

plt.tight_layout()
plt.show()
import matplotlib.pyplot as plt
import librosa.display
from gtts import gTTS
import numpy as np

text = "Hello, I am Mariam Borshkova"
tts = gTTS(text, lang='en')
tts.save("Mariami.wav")

audio_path = "Mariami.wav"
y, sr = librosa.load(audio_path, sr=None)


plt.figure(figsize=(10, 4))
librosa.display.waveshow(y, sr=sr)
plt.title('Sound Waveform')
plt.xlabel('Time (seconds)')
plt.ylabel('Amplitude')
plt.tight_layout()
plt.show()

frame_length = int(0.02 * sr)  
hop_length = frame_length
frames = librosa.util.frame(y, frame_length=frame_length, hop_length=hop_length)




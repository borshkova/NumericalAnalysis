import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
from scipy.signal import decimate, butter, filtfilt
from scipy.interpolate import interp1d, CubicSpline


filename = 'Mariami.wav'
data, sample_rate = sf.read(filename)


downsample_factor = 4 
nyquist = 0.5 * sample_rate
cutoff = nyquist / downsample_factor


b, a = butter(4, cutoff / nyquist, btype='low')
data_filtered = filtfilt(b, a, data)


data_downsampled = data_filtered[::downsample_factor]
t = np.arange(len(data)) / sample_rate
t_downsampled = t[::downsample_factor]


t_interpolated = np.linspace(0, t_downsampled[-1], len(data), endpoint=False)


data_interpolated_linear = np.interp(t_interpolated, t_downsampled, data_downsampled)


sf.write('linear_interpolated.wav', data_interpolated_linear, sample_rate)

plt.figure(figsize=(10, 6))
plt.plot(t, data, label='Original', alpha=0.5)
plt.plot(t_interpolated, data_interpolated_linear, label='Linear Interpolation', alpha=0.75)
plt.legend()
plt.title('Linear Interpolation of Audio Signal')
plt.xlabel('Time [s]')
plt.ylabel('Amplitude')
plt.show()

cubic_interp = interp1d(t_downsampled, data_downsampled, kind='cubic')
data_interpolated_cubic = cubic_interp(t_interpolated)


sf.write('cubic_interpolated.wav', data_interpolated_cubic, sample_rate)

plt.figure(figsize=(10, 6))
plt.plot(t, data, label='Original', alpha=0.5)
plt.plot(t_interpolated, data_interpolated_cubic, label='Cubic Interpolation', alpha=0.75)
plt.legend()
plt.title('Cubic Interpolation of Audio Signal')
plt.xlabel('Time [s]')
plt.ylabel('Amplitude')
plt.show()

spline_interp = CubicSpline(t_downsampled, data_downsampled)
data_interpolated_spline = spline_interp(t_interpolated)

sf.write('spline_interpolated.wav', data_interpolated_spline, sample_rate)

plt.figure(figsize=(10, 6))
plt.plot(t, data, label='Original', alpha=0.5)
plt.plot(t_interpolated, data_interpolated_spline, label='Spline Interpolation', alpha=0.75)
plt.legend()
plt.title('Spline Interpolation of Audio Signal')
plt.xlabel('Time [s]')
plt.ylabel('Amplitude')
plt.show()

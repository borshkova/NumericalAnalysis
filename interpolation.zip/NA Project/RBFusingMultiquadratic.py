import cv2
import numpy as np
from scipy.spatial.distance import cdist

def mq_rbf_interpolation(points, values, xi, c):
    r = cdist(points, points, 'euclidean')
    phi = np.sqrt(1 + (c * r)**2)
    weights = np.linalg.solve(phi, values)
    
    r_xi = cdist(xi, points, 'euclidean')
    phi_xi = np.sqrt(1 + (c * r_xi)**2)
    
    return np.dot(phi_xi, weights)

def interpolate_image(image, num_points=450, shape_parameter=0.5):
    height, width, channels = image.shape
    interpolated_image = np.zeros((height, width, channels), dtype=np.uint8)
    
    for channel in range(channels):
        channel_data = image[:, :, channel]
        channel_normalized = channel_data / 255.0
       
        control_points = np.column_stack((np.random.randint(0, height, num_points),
                                          np.random.randint(0, width, num_points)))
        control_values = channel_normalized[control_points[:, 0], control_points[:, 1]]
        
        grid_x, grid_y = np.mgrid[0:height, 0:width]
        grid_points = np.column_stack((grid_x.ravel(), grid_y.ravel()))
        
        interpolated_values = mq_rbf_interpolation(control_points, control_values, grid_points, shape_parameter)
        interpolated_channel = interpolated_values.reshape((height, width))
        
        interpolated_image[:, :, channel] = np.clip(interpolated_channel * 255, 0, 255).astype(np.uint8)
    
    return interpolated_image

image = cv2.imread('image.jpg')

interpolated_image = interpolate_image(image)

cv2.imwrite('interpolated_image_color.jpg', interpolated_image)
cv2.imshow('Interpolated Image', interpolated_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
